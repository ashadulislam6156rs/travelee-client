
import ForgotPasswordFun from '@/components/Auth/ForgotPassword';
import Link from 'next/link';

import React from 'react';
import { IoPlayBackOutline } from 'react-icons/io5';

const ForgotPassword = () => {
    return (
      <div className="flex justify-center gap-5 items-center min-h-screen flex-col ">
        <div >
          <Link
            className="px-4 items-center gap-2 flex py-2 text-white text-sm font-medium bg-primary hover:bg-primary/90 rounded-lg transition-colors duration-200"
            href="/"
          >
            <IoPlayBackOutline />
            Back home
          </Link>
        </div>
        <div>
          <ForgotPasswordFun></ForgotPasswordFun>
        </div>
      </div>
    );
};

export default ForgotPassword;